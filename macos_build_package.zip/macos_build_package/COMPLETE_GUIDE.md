# 🍎 Complete macOS Build Guide for Wellness at Work

## 📋 Overview
This package contains everything needed to build the Wellness at Work desktop application for macOS and create a DMG installer.

## 🎯 What You'll Get
- **WellnessAtWork.app** - Native macOS application bundle
- **WellnessAtWork-1.0.0.dmg** - Professional installer package
- Full icon integration and system tray support

## 🔧 Prerequisites (on your MacBook)

### 1. Install Homebrew (if not already installed)
```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
```

### 2. Install Python 3.11
```bash
brew install python@3.11
```

### 3. Install DMG creation tool
```bash
brew install create-dmg
```

### 4. Install Pillow for icon conversion
```bash
pip3 install Pillow
```

## 🚀 Build Process

### Step 1: Verify Prerequisites
```bash
chmod +x *.sh
./verify_prerequisites.sh
```

### Step 2: Convert Icon (if needed)
```bash
python3 convert_icon_for_macos.py
```

### Step 3: Build Application
```bash
./build_macos_app.sh
```

### Step 4: Find Your Built Application
The build process creates:
- `dist_macos/WellnessAtWork.app` - The application bundle
- `WellnessAtWork-1.0.0.dmg` - The installer package

## 📦 Installation & Testing

### For Testing (Quick Method)
1. Double-click `WellnessAtWork-1.0.0.dmg`
2. Drag `WellnessAtWork.app` to Applications
3. Right-click the app → Open (first time only)

### For Distribution
- Share the `.dmg` file with other users
- They can install it the same way

## ⚠️ Security Notes

Since the app is unsigned (requires Apple Developer account), users will see security warnings:

### First Launch
1. Right-click the app → "Open"
2. Click "Open" when prompted
3. App will launch normally afterward

### If Blocked Completely
1. System Preferences → Security & Privacy
2. Click "Open Anyway" next to the blocked app warning
3. Or temporarily allow unsigned apps

## 🔧 Troubleshooting

### Python Module Errors
```bash
pip3 install -r requirements.txt
pip3 install -r requirements.backend.txt
```

### Permission Errors
```bash
chmod +x build_macos_app.sh
chmod +x verify_prerequisites.sh
```

### Icon Not Showing
The build script automatically handles icon conversion, but if needed:
```bash
python3 convert_icon_for_macos.py
```

### Build Fails
1. Check all prerequisites are installed
2. Ensure you're in the correct directory
3. Try running commands step by step

## 📊 Expected Results

### Build Time
- Initial setup: 5-10 minutes
- Actual build: 3-5 minutes
- Total: ~15 minutes

### File Sizes
- Application bundle: ~300-400 MB
- DMG installer: ~250-350 MB

### Features Included
- ✅ Eye tracking with MediaPipe
- ✅ Real-time blink detection
- ✅ System tray integration
- ✅ Offline data storage
- ✅ Automatic backend sync
- ✅ Professional macOS interface

## 🎉 Success Indicators

When successful, you should see:
```
✅ PyInstaller completed successfully
✅ Application bundle created: dist_macos/WellnessAtWork.app
✅ DMG created successfully: WellnessAtWork-1.0.0.dmg
🎉 macOS build completed successfully!
```

## 📞 Support

If you encounter issues:
1. Check the terminal output for specific error messages
2. Verify all prerequisites are installed correctly
3. Ensure you have sufficient disk space (>2GB recommended)

---

**Backend Configuration**: https://waw-backend-a28q.onrender.com
**Build Date**: $(date)
**Version**: 1.0.0
