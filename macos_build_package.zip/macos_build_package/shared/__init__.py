"""Shared utilities for WaW project."""
